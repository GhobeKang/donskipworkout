# DON'T SKIP Google Play assets

한국어와 영어 스토어 등록용 PNG입니다. 언어별 폴더의 파일만 Play Console에 업로드하세요.

| 파일 | 규격 | 순서 / 용도 |
| --- | --- | --- |
| `feature_graphic.png` | 1024 × 500, RGB PNG | Feature graphic |
| `phone_01_today.png` | 1080 × 1920, RGB PNG | 오늘과 주간 출석 |
| `phone_02_workout.png` | 1080 × 1920, RGB PNG | 운동 중량·반복·세트 기록 |
| `phone_03_records.png` | 1080 × 1920, RGB PNG | 출석 캘린더 |
| `phone_04_challenges.png` | 1080 × 1920, RGB PNG | 친구와 챌린지 |

`en/`은 영어, `ko/`는 한국어입니다. `preview.png`는 검토용 모음 이미지이며 업로드 대상이 아닙니다.

## 제작과 검증

- Feature graphic의 배경은 built-in ImageGen으로 기존 앱 캐릭터를 참고해 생성했습니다. 문구는 별도로 조판해 글자가 깨지지 않도록 했습니다.
- 휴대전화 이미지는 실제 앱 컴포넌트를 Chromium에서 캡처한 후 제목을 추가했습니다. 화면에는 가상의 예시 운동 기록과 챌린지를 사용했습니다.
- 캡처 중 모든 API 요청은 브라우저 내부의 예시 응답으로 처리합니다. 실제 서버·회원·운동 기록을 변경하지 않습니다.
- 외부 글꼴 연결이 제한된 캡처 환경에서 Google의 원래 Material Symbols Rounded 글꼴을 로컬로 로드했습니다.
- 캡처 과정에서 발견된 타이머 등의 영어 번역 누락과 일요일 표시 오류를 실제 앱 소스에 보완했습니다. 이번 이미지는 해당 수정이 포함된 화면입니다.
- 모든 업로드 PNG는 RGB 3채널, 알파 없음입니다. 파일별 크기는 `source/asset_manifest.json`, 브라우저 오류 확인은 `source/capture_log.json`을 참고하세요.

Google 규격: https://support.google.com/googleplay/android-developer/answer/9866151?hl=en

## 재생성

프로젝트에서 개발 서버를 실행하고 다음 명령을 사용합니다. 앱 코드를 변경한 뒤에는 최신 개발 서버를 대상으로 다시 캡처하세요.

```powershell
npm run dev -- --port 4177
$env:APP_PREVIEW_URL = 'http://localhost:4177'
node docs/store-assets/source/generate_assets.cjs
```

스크립트는 Codex에 번들된 Playwright·Sharp와 설치된 Chrome을 사용합니다. `APP_PREVIEW_URL`을 생략하면 기존 `out/` 정적 export를 캡처합니다.
캐릭터 배경만 교체한 경우 `node docs/store-assets/source/generate_assets.cjs --feature-only`로
휴대전화 화면을 다시 캡처하지 않고 한영 feature graphic과 미리보기만 재생성합니다.

## ImageGen prompt

Initial artwork: built-in ImageGen, reference-guided `ads-marketing` generation.

Reference: `public/assets/character/coach-playful-wink-transparent.png`.

Prompt: Create a wide 2048 × 1000 premium fitness-app campaign background for DON'T SKIP. Preserve the existing charcoal muscular mascot, cream facial features, cheeky wink, peace hand gesture and red gym shorts. Position the waist-up mascot on the right, leaving the left area clear for separately typeset copy. Use matte charcoal #121416, peach-orange #ff894a rim lighting, and a subtle rising orange arc. Keep the face and gesture inside safe margins. No text, logos, app icons, phone mockups, UI, or watermarks. Opaque background.

Generated artwork: `source/feature_artwork.png`. Upload graphics use localized text; the artwork is shared between the languages.

## 2026-10-20 표정과 포즈 수정

- 윙크·내민 혀·브이 손동작을 없애고, 양눈을 뜬 집중한 시선과 다문 입으로 수정했습니다.
- 한 주먹은 가슴 앞에, 다른 주먹은 허리 옆에 쥔 준비 자세로 바꿨습니다.
- 기존 캐릭터, 배경, 색상과 한영 문구는 유지했습니다. 최종 한영 PNG는 1024×500 RGB이며 알파가 없습니다.
- 기존 장난스러운 원본은 `review/2026-10-20-playful-feature/`, 표정만 수정했던 중간안은
  `review/2026-10-20-expression-only/`에 보관했습니다. 앱 내부 캐릭터는 변경하지 않았습니다.
- 사용자의 최종본 업로드 승인 후 Play Console의 한국어·영어 feature graphic을 각각 교체하고
  `Your changes have been saved`를 확인했습니다. 기존 앱 이름·설명문과 각 언어의 스크린샷 7장은 유지했습니다.
- 초안으로 저장했으며 심사 전송은 실행하지 않았습니다. 반영 화면과 검증 기록은 `proof/2026-10-20-*`에 있습니다.

Mode: built-in ImageGen edit, `precise-object-edit`.

Final prompt: Edit the existing DON'T SKIP feature graphic background. Change the pose as well as the face.
Remove the peace-sign gesture. Make the torso upright and shoulders squared, with one clenched fist close
in front of the upper chest and the other near the waist, communicating a supportive fitness coach's
commitment to a workout. Both eyes open with focused forward attention, cream eyebrows angled inward,
and a short closed firm mouth. No wink, tongue, grin, salute, raised individual fingers, fighting or rage.
Preserve the charcoal muscular mascot, swept spiky hair, cream graphic facial features, red shorts,
premium 3D materials, right-side character placement, orange rim light and rising arc, charcoal background
and empty left copy space. Wide landscape approximately 2048×1000, opaque. No text, logos or watermark.

## 2026-10-20 캐릭터 시트 적용

최신 기준은 `public/assets/character/character-sheet.png`입니다. Feature graphic의 캐릭터 얼굴을
시트의 기본 찡그린 표정과 원형 눈, 짧고 넓은 체형으로 교체했습니다. 기존 준비 자세와 배경,
한영 조판 및 1024×500 RGB 규격은 유지했습니다. 직전 이미지는 `review/2026-10-20-before-character-sheet/`에 보관했습니다.

Mode: built-in ImageGen edit. Latest prompt: Image 1 is the existing feature background; image 2 is
the definitive character sheet. Replace only the mascot identity with the sheet's squat heavyweight
charcoal body, round head, swept hair, cream circular eyes, inward-angled eyebrows and downturned cream
mouth. Retain the clenched-fist ready pose, red shorts, right-side framing, orange rim light, rising arc,
charcoal background and empty left copy space. One character; no sheet layout, text, logos or watermark.

App Store 공용 이미지 원본도 같은 투명 캐릭터로 재생성했습니다. 실제 App Store Connect의 한국어
헤더·검색 결과에는 등록된 자산이 없어 새로 업로드하지 않았습니다. 일반 앱 화면에는 캐릭터 직접 표시가 없으며,
현재 활성 사용처는 서버의 인증 사진 합성과 Google Play feature graphic입니다.

## Font license

Material Symbols Rounded is provided by Google under the Apache License 2.0. The font and license are retained in `source/` for reproducible capture.
