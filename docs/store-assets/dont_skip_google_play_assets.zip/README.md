# DON'T SKIP Google Play assets

한국어와 영어 스토어 등록용 PNG입니다. 언어별 폴더의 파일만 Play Console에 업로드하세요.

| 파일 | 규격 | 순서 / 용도 |
| --- | --- | --- |
| `feature_graphic.png` | 1024 × 500, RGB PNG | Feature graphic |
| `phone_01_today.png` | 1080 × 1920, RGB PNG | 오늘과 주간 출석 |
| `phone_02_workout.png` | 1080 × 1920, RGB PNG | 운동 중량·반복·세트 기록 |
| `phone_03_records.png` | 1080 × 1920, RGB PNG | 출석 캘린더 |
| `phone_04_challenges.png` | 1080 × 1920, RGB PNG | 친구와 챌린지 |

`en/`은 영어, `ko/`는 한국어입니다. `preview.png`는 검토용 모음 이미지이며 업로드 대상이 아닙니다.

## 제작과 검증

- Feature graphic의 배경은 built-in ImageGen으로 기존 앱 캐릭터를 참고해 생성했습니다. 문구는 별도로 조판해 글자가 깨지지 않도록 했습니다.
- 휴대전화 이미지는 실제 앱 컴포넌트를 Chromium에서 캡처한 후 제목을 추가했습니다. 화면에는 가상의 예시 운동 기록과 챌린지를 사용했습니다.
- 캡처 중 모든 API 요청은 브라우저 내부의 예시 응답으로 처리합니다. 실제 서버·회원·운동 기록을 변경하지 않습니다.
- 외부 글꼴 연결이 제한된 캡처 환경에서 Google의 원래 Material Symbols Rounded 글꼴을 로컬로 로드했습니다.
- 캡처 과정에서 발견된 타이머 등의 영어 번역 누락과 일요일 표시 오류를 실제 앱 소스에 보완했습니다. 이번 이미지는 해당 수정이 포함된 화면입니다.
- 모든 업로드 PNG는 RGB 3채널, 알파 없음입니다. 파일별 크기는 `source/asset_manifest.json`, 브라우저 오류 확인은 `source/capture_log.json`을 참고하세요.

Google 규격: https://support.google.com/googleplay/android-developer/answer/9866151?hl=en

## 재생성

프로젝트에서 개발 서버를 실행하고 다음 명령을 사용합니다. 앱 코드를 변경한 뒤에는 최신 개발 서버를 대상으로 다시 캡처하세요.

```powershell
npm run dev -- --port 4177
$env:APP_PREVIEW_URL = 'http://localhost:4177'
node docs/store-assets/source/generate_assets.cjs
```

스크립트는 Codex에 번들된 Playwright·Sharp와 설치된 Chrome을 사용합니다. `APP_PREVIEW_URL`을 생략하면 기존 `out/` 정적 export를 캡처합니다.

## ImageGen prompt

Mode: built-in ImageGen, reference-guided `ads-marketing` generation.

Reference: `public/assets/character/coach-playful-wink-transparent.png`.

Prompt: Create a wide 2048 × 1000 premium fitness-app campaign background for DON'T SKIP. Preserve the existing charcoal muscular mascot, cream facial features, cheeky wink, peace hand gesture and red gym shorts. Position the waist-up mascot on the right, leaving the left area clear for separately typeset copy. Use matte charcoal #121416, peach-orange #ff894a rim lighting, and a subtle rising orange arc. Keep the face and gesture inside safe margins. No text, logos, app icons, phone mockups, UI, or watermarks. Opaque background.

Generated artwork: `source/feature_artwork.png`. Upload graphics use localized text; the artwork is shared between the languages.

## Font license

Material Symbols Rounded is provided by Google under the Apache License 2.0. The font and license are retained in `source/` for reproducible capture.
